package com.unasat.blackjack;

public enum Suit {

    CLUB, DIAMOND, SPADE, HEART
}
