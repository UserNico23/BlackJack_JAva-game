package com.unasat.blackjack;

import java.util.ArrayList;
import java.util.Random;

public class Deck {

    //constructor maken voor Deck
    //isntance variable Arraylisy cards
    //Arraylistt van cards


    //instance vars
    private ArrayList<Card> cards;

    //construtor
    public Deck(){
        this.cards = new ArrayList<Card>();
    }

    //method om een full deck of cards te maken
    public void createFullDeck(){
        //Cards genereren
        for (Suit cardSuit : Suit.values()){
            for(Values cardValue : Values.values()){
                //add new card to the mix
                this.cards.add(new Card(cardSuit, cardValue));
            }
        }
    }

    //method om deck class te shufflen
    public void shuffle(){
      ArrayList<Card> tmpDeck = new ArrayList<Card>();
      //random object gebruiken om random numbers te genereren
        Random random = new Random();
        int randomCardIndex = 0;
        int originalSize = this.cards.size();

        for(int i = 0; 1 < originalSize; i++){
            //generate random index rand.nextInt((max - min) + 1) + min;
            randomCardIndex = random.nextInt((this.cards.size() - 1 - 0) + 1) +0;
            tmpDeck.add(this.cards.get(randomCardIndex));

            //remove from original deck
            this.cards.remove(randomCardIndex);
        }
        this.cards = tmpDeck;
    }

    //return String met alle cards
    public String toString(){
        String cardListOutPut = "";
        //Loop dat String uitprint met alle cardvalues
         int i = 0;
         for (Card aCard : this.cards){
             cardListOutPut += "\n" + i + "-" + aCard.toString();
             i++;
         }
         return cardListOutPut;
    }

}
