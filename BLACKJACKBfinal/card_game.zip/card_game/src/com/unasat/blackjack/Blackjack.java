package com.unasat.blackjack;

//hier komt main game logic
public class Blackjack {

    public static void main(String[] args){
        //welcome message
        System.out.println("Welcome to BlackJack!");

        //Deck maken

        Deck playingDeck = new Deck();
        playingDeck.createFullDeck();
        playingDeck.shuffle();

        System.out.println(playingDeck);
    }
}
